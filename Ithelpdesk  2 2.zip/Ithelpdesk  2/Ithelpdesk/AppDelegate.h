//
//  AppDelegate.h
//  Ithelpdesk
//
//  Created by omniwyse on 01/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import <Firebase.h>
#import <FirebaseAuth/FirebaseAuth.h>
#import <UserNotifications/UserNotifications.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (nonatomic, retain, readonly) NSManagedObjectModel *managedObjectModel;
@property (nonatomic, retain, readonly) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain, readonly) NSPersistentStoreCoordinator *persistentStoreCoordinator;
@property (readonly, strong) NSPersistentContainer *persistentContainer;

-(NSURL*)applicationDocumentsDirectory;


@property (strong, nonatomic) UIWindow *window;


@end

