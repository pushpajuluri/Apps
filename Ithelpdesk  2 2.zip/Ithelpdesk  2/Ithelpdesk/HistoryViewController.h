//
//  HistoryViewController.h
//  Ithelpdesk
//
//  Created by omniwyse on 13/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface HistoryViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (weak, nonatomic) IBOutlet UITableView *tableview;
@property (strong) NSMutableArray *devices;
@end
