//
//  CustomButtonClass.h
//  Pods
//
//  Created by ibasemac3 on 3/17/17.
//
//

#import <UIKit/UIKit.h>

@interface CustomButtonClass : UIButton

-(void)setTitleColor:(UIColor *)color andFontsize:(int)fontSize andTitle:(int)title;


@end
