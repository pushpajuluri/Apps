//
//  AppDelegate.h
//  Ithelpdesk
//
//  Created by omniwyse on 01/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Firebase.h>
#import <FirebaseAuth/FirebaseAuth.h>
#import <UserNotifications/UserNotifications.h>


@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

