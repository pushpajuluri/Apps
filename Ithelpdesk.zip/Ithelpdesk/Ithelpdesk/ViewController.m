//
//  ViewController.m
//  Ithelpdesk
//
//  Created by omniwyse on 01/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import "ViewController.h"
#import "SKPSMTPMessage.h"
#import "NSData+Base64Additions.h"
#import "NSString+FontAwesome.h"
#import "CustomButtonClass.h"
#import "FontAwesomeButton.h"
#import <Firebase.h>
#import <FirebaseAuth/FirebaseAuth.h>
#import "VerifyViewController.h"


@interface ViewController ()<SKPSMTPMessageDelegate>


@end

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    [self colors];
    _arrayNo =@[@"laptops",@"desktops"];
    [_txtSelectItem addTarget:self action:@selector(textFieldDidChange:)forControlEvents:UIControlEventEditingChanged];
    [_picker reloadAllComponents];
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(highlightLetter:)];
    tapGesture.numberOfTapsRequired = 1;
    [_txtSelectItem addGestureRecognizer:tapGesture];
    [_txtSelectItem setUserInteractionEnabled:YES];
    _picker.hidden = YES;
    
    
}
//picker called method

-(void)textFieldDidChange :(UITextField *)theTextField{
  [_txtSelectItem resignFirstResponder];
     _picker.hidden = NO;
}

- (void)highlightLetter:(UITapGestureRecognizer*)sender {
    _picker.hidden = NO;
}


- (IBAction)Submit:(id)sender {
    NSString *Name = _txtName.text;
    NSString *phone = _txtPhoneNumber.text;
    NSString *Email = _txtMail.text;
    NSString *location = _txtLocation.text;
    NSString *message = _txtMessage.text;
    
    
    NSLog(@"Start Sending");
    SKPSMTPMessage *emailMessage = [[SKPSMTPMessage alloc] init];
    emailMessage.fromEmail = @"myhelpdeskit@gmail.com"; //sender email address
    emailMessage.toEmail = [NSString stringWithFormat:@"%@",Email];  //receiver email address
    emailMessage.relayHost = @"smtp.gmail.com";
    emailMessage.ccEmail =@"mukesh.kumar@gmail.com";
    //emailMessage.bccEmail =@"your bcc address";
    emailMessage.requiresAuth = YES;
    emailMessage.login = @"myhelpdeskit@gmail.com"; //sender email address
    emailMessage.pass = @"Rangam@5"; //sender email password
    emailMessage.subject =@"email subject header message";
    emailMessage.wantsSecure = YES;
    emailMessage.delegate = self; // you must include <SKPSMTPMessageDelegate> to your class
    NSString *messageBody =[NSString stringWithFormat:@"%s%@%s%s%@%s%s%@%s%s%@","Name:",Name,"\n","Contact number:",phone,"\n","Location:",location,"\n","message:",message];
   
    NSDictionary *plainMsg = [NSDictionary
                              dictionaryWithObjectsAndKeys:@"text/plain",kSKPSMTPPartContentTypeKey,
                              messageBody,kSKPSMTPPartMessageKey,@"8bit",kSKPSMTPPartContentTransferEncodingKey,nil];
    emailMessage.parts = [NSArray arrayWithObjects:plainMsg,nil];
    
    [emailMessage send];
    
}


#pragma mark- uicolor and border
-(void)colors
{
    
    [self.btnName setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAUser];
    [self.btnEmail setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAUser];
    [self.btnPhoneNumber setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAEnvelopeO];
    [self.btnSelectIteam setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAKey];
    [self.btnLocation setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAKey];
    
    _txtName.layer.borderWidth = 1.0f;
    _txtName.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _txtName.layer.cornerRadius = 8.0f;
    _txtMail.layer.borderWidth = 1.0f;
    _txtMail.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _txtMail.layer.cornerRadius = 8.0f;
    _txtPhoneNumber.layer.borderWidth = 1.0f;
    _txtPhoneNumber.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _txtPhoneNumber.layer.cornerRadius = 8.0f;
    _txtLocation.layer.borderWidth = 1.0f;
    _txtLocation.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _txtLocation.layer.cornerRadius = 8.0f;
    _txtMessage.layer.borderWidth = 1.0f;
    _txtMessage.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _txtMessage.layer.cornerRadius = 8.0f;
    _txtSelectItem.layer.borderWidth = 1.0f;
    _txtSelectItem.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _txtSelectItem.layer.cornerRadius = 8.0f;

}
-(BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = NO;
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}
-(void)messageSent:(SKPSMTPMessage *)message{
    NSLog(@"delegate - message sent");
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message sent." message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    [alert show];
}
// On Failure
-(void)messageFailed:(SKPSMTPMessage *)message error:(NSError *)error{
    // open an alert with just an OK button
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    [alert show];
    NSLog(@"delegate - error(%d): %@", [error code], [error localizedDescription]);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
// The number of rows of data
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _arrayNo.count;
}
// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return _arrayNo[row];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    _picker.hidden = YES;
    _txtSelectItem.text = _arrayNo[row];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}
- (IBAction)verifying:(id)sender {
    NSString *phone = _txtPhoneNumber.text;
    [[FIRPhoneAuthProvider provider] verifyPhoneNumber:[NSString stringWithFormat:@"%@",phone]
                                            UIDelegate:nil
                                            completion:^(NSString * _Nullable verificationID, NSError * _Nullable error) {
                                                if (error) {
                                                    NSLog(@"Push Error");
                                                    return;
                                                }
                                                NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                                                [defaults setObject:verificationID forKey:@"authVerificationID"];
                                                VerifyViewController *rc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]
                                                                                    instantiateViewControllerWithIdentifier:@"VerifyViewController"];
                                                [self.navigationController pushViewController:rc animated:YES];
                                            }];
    
}


@end
