//
//  ViewController.m
//  Ithelpdesk
//
//  Created by omniwyse on 01/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import "ViewController.h"
#import "SKPSMTPMessage.h"
#import "NSData+Base64Additions.h"
#import "NSString+FontAwesome.h"
#import "CustomButtonClass.h"
#import "FontAwesomeButton.h"
#import <Firebase.h>
#import <FirebaseAuth/FirebaseAuth.h>
#import "VerifyViewController.h"
#import "HistoryViewController.h"


@interface ViewController ()<SKPSMTPMessageDelegate>
{
    NSString *filePath1;
    UIActivityIndicatorView *activityIndicator;
     NSString *phoneimagepath;
    NSManagedObject *newDevice;
    
}

@end

@implementation ViewController



- (void)viewDidLoad {
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0ul);
    [super viewDidLoad];
    [self colors];
    _arrayNo =@[@"laptops",@"desktops"];
    [_txtSelectItem addTarget:self action:@selector(textFieldDidChange:)forControlEvents:UIControlEventEditingChanged];
    [_picker reloadAllComponents];
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(highlightLetter:)];
    tapGesture.numberOfTapsRequired = 1;
    [_txtSelectItem addGestureRecognizer:tapGesture];
    [_txtSelectItem setUserInteractionEnabled:YES];
    _picker.hidden = YES;
    UIActivityIndicatorView *spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    [self.view addSubview:spinner];
    [spinner setFrame:CGRectMake((self.view.frame.size.width/2)-(spinner.frame.size.width/2), (self.view.frame.size.height/2)-(spinner.frame.size.height/2), spinner.frame.size.width, spinner.frame.size.height)];
    
    _imgVerification.image = [UIImage imageNamed: @"ex.png"];
    UIBarButtonItem *Savebtn=[[UIBarButtonItem alloc]initWithImage:
                              [[UIImage imageNamed:@"history.png"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]
                                                             style:UIBarButtonItemStylePlain target:self action:@selector(SaveButtonClicked)];
    self.navigationItem.rightBarButtonItem=Savebtn;
    
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:0.7
                                                      target:[NSBlockOperation blockOperationWithBlock:^{ [self sendMails]; }]
                                                    selector:@selector(main)
                                                    userInfo:nil
                                                     repeats:NO
                      ];
//    [NSTimer timerWithTimeInterval:30.0 repeats:YES block:^(NSTimer * _Nonnull timer) {
//
//        [self sendMails];
//
//    }];
    if ([[Reachability reachabilityForInternetConnection]currentReachabilityStatus]==NotReachable)
        
    {
        [newDevice setValue:@"no" forKey:@"statussync"];
        
    }
    else
    {
       
    }
}
//picker called method
-(void)SaveButtonClicked{
    HistoryViewController *rc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]
                                        instantiateViewControllerWithIdentifier:@"HistoryViewController"];
    [self.navigationController pushViewController:rc animated:YES];
    
}

-(void)textFieldDidChange :(UITextField *)theTextField{
  [_txtSelectItem resignFirstResponder];
     _picker.hidden = NO;
}

- (void)highlightLetter:(UITapGestureRecognizer*)sender {
    [_txtSelectItem resignFirstResponder];
    _picker.hidden = NO;
}

- (NSManagedObjectContext *)managedObjectContext {
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}


-(void)sendMails{
    
    if ([[Reachability reachabilityForInternetConnection]currentReachabilityStatus]!=NotReachable){
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"IthelpdeskEntity"];
    NSMutableArray *devices = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    
    //Background Thread
  //  dispatch_async(dispatch_get_main_queue(), ^(void){
        //Run UI Updates
        
        
        for (NSArray *device in devices)
        {
            NSString *value =  [device valueForKey:@"statussync"];
            if([value isEqual: @"no"]){
                NSString *emailDb = [device valueForKey:@"email"];
                NSString *location = [device valueForKey:@"location"];
                NSString *message = [device valueForKey:@"message"];
                NSString *mobile = [device valueForKey:@"mobile"];
                NSString *name = [device valueForKey:@"name"];
                NSString *selectiteam = [device valueForKey:@"selecteditem"];
                NSString *dbpath= [device valueForKey:@"imagepaths"];
                SKPSMTPMessage *emailMessage = [[SKPSMTPMessage alloc] init];
                emailMessage.fromEmail = @"myhelpdeskit@gmail.com"; //sender email address
                emailMessage.toEmail = [NSString stringWithFormat:@"%@",emailDb]; //receiver email address
                emailMessage.relayHost = @"smtp.gmail.com";
                emailMessage.ccEmail =@"mukesh.kumar@gmail.com";
                emailMessage.messageId=[device valueForKey:@"id"];
                //emailMessage.bccEmail =@"your bcc address";
                emailMessage.requiresAuth = YES;
                emailMessage.login = @"myhelpdeskit@gmail.com"; //sender email address
                emailMessage.pass = @"Rangam@5"; //sender email password
                emailMessage.subject =[NSString stringWithFormat:@"%s%@","Complaint:",selectiteam];
                emailMessage.wantsSecure = YES;
                emailMessage.delegate = self; // you must include <SKPSMTPMessageDelegate> to your class
                NSString *messageBody =[NSString stringWithFormat:@"%s%@%s%s%@%s%s%@%s%s%@","Name:",name,"\n","Contact number:",mobile,"\n","Location:",location,"\n","message:",message];
                
                NSDictionary *plainMsg = [NSDictionary
                                          dictionaryWithObjectsAndKeys:@"text/plain",kSKPSMTPPartContentTypeKey,
                                          messageBody,kSKPSMTPPartMessageKey,@"8bit",kSKPSMTPPartContentTransferEncodingKey,nil];
                NSData *fileData1 = [NSData dataWithContentsOfFile:dbpath];
                NSDictionary *fileMsg1 = [NSDictionary dictionaryWithObjectsAndKeys:@"directory;\r\n\tname=\"ganesh.jpg\"",kSKPSMTPPartContentTypeKey,@"attachment;\r\n\tganesh=\"ganesh.jpg\"",kSKPSMTPPartContentDispositionKey,[fileData1 encodeBase64ForData],kSKPSMTPPartMessageKey,@"base64",kSKPSMTPPartContentTransferEncodingKey,nil];
                emailMessage.parts = [NSArray arrayWithObjects:plainMsg,fileMsg1,nil];
              //  dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                    [emailMessage send];
             //   });
            }
        }
  //  });
    }
}

- (IBAction)Submit:(id)sender
{
    activityIndicator.transform = CGAffineTransformMakeScale(2.0, 2.0);
    NSManagedObjectContext *context = [self managedObjectContext];
    
    // Create a new managed object
    newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"IthelpdeskEntity" inManagedObjectContext:context];
    [newDevice setValue:_txtName.text forKey:@"name"];
    [newDevice setValue:_txtMail.text forKey:@"email"];
    [newDevice setValue:_txtLocation.text forKey:@"location"];
    [newDevice setValue:_txtMessage.text forKey:@"message"];
    [newDevice setValue:_txtSelectItem.text forKey:@"selecteditem"];
    [newDevice setValue:_txtPhoneNumber.text forKey:@"mobile"];
    [newDevice setValue:filePath1 forKey:@"imagepaths"];
    [newDevice setValue:@"no" forKey:@"statussync"];
    [newDevice setValue:[NSString stringWithFormat:@"%f",round([[NSDate date] timeIntervalSince1970])] forKey:@"id"];
    NSError *error = nil;
    // Save the object to persistent store
    if (![context save:&error]) {
        NSLog(@"Can't Save! %@ %@", error, [error localizedDescription]);
    }
    
 
    [self.activityIndicator startAnimating];
    
  
}

-(void)messageSent:(SKPSMTPMessage *)message{
     NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSManagedObjectContext *context = [self managedObjectContext];
   // NSEntityDescription *entity = [NSEntityDescription entityForName:@"Ithelpdesk" inManagedObjectContext:context];
    [request setEntity:[NSEntityDescription entityForName:@"IthelpdeskEntity" inManagedObjectContext:context]];
    // [request setEntity:entity];
    NSError *error = nil;
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"id==%@", message.messageId];
    [request setPredicate:predicate];
    
    NSArray *results = [context executeFetchRequest:request error:&error];
    if(results.count>0)
    {
        NSArray *device = results.firstObject;
        [device setValue:@"yes" forKey:@"statussync"];
    }
    [self.managedObjectContext save:nil];

    
    //NSPredicate *predicate=[NSPredicate predicateWithFormat:@"statussync==%@"]; // If required to fetch specific vehicle
   // fetchRequest.predicate=predicate;
   // NSManagedObject *updatedDevice=[[self.managedObjectContext executeFetchRequest:fetchRequest error:nil] lastObject];
    // [updatedDevice setValue:@"yes" forKey:@"statussync"];
  //  NSManagedObjectContext *context = [self managedObjectContext];
    
    // Create a new managed object
 //   newDevice = [NSEntityDescription insertNewObjectForEntityForName:@"IthelpdeskEntity" inManagedObjectContext:context];
//    [newDevice setValue:@"yes" forKey:@"statussync"];
//    [self.managedObjectContext save:nil];
//    activityIndicator.transform = CGAffineTransformIdentity;
//
//    [self.activityIndicator stopAnimating];
//
//
//    NSLog(@"delegate - message sent");
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Message sent." message:nil delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
//    [alert show];
//    ViewController *rc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]
//                          instantiateViewControllerWithIdentifier:@"ViewController"];
//    [self.navigationController pushViewController:rc animated:YES];
}
-(void)messageFailed:(SKPSMTPMessage *)message error:(NSError *)error{
    // open an alert with just an OK button
    [newDevice setValue:@"no" forKey:@"statussync"];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:[error localizedDescription] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
    [alert show];
    NSLog(@"delegate - error(%d): %@", [error code], [error localizedDescription]);
}


#pragma mark- uicolor and border
-(void)colors
{
    
//    [self.btnName setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAUser];
//    [self.btnEmail setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAUser];
//    [self.btnPhoneNumber setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAEnvelopeO];
//    [self.btnSelectIteam setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAKey];
//    [self.btnLocation setTitleColor:[UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1] andFontsize:20.0 andTitle:FAKey];
    
    _viName.layer.borderWidth = 1.0f;
    _viName.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viName.layer.cornerRadius = 8.0f;
    _viMail.layer.borderWidth = 1.0f;
    _viMail.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viMail.layer.cornerRadius = 8.0f;
    _viPhoneNumber.layer.borderWidth = 1.0f;
    _viPhoneNumber.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viPhoneNumber.layer.cornerRadius = 8.0f;
    _viLocation.layer.borderWidth = 1.0f;
    _viLocation.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viLocation.layer.cornerRadius = 8.0f;
    _viMsg.layer.borderWidth = 1.0f;
    _viMsg.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viMsg.layer.cornerRadius = 8.0f;
    _viSelectItem.layer.borderWidth = 1.0f;
    _viSelectItem.layer.borderColor = [UIColor colorWithRed:204.0/255.0 green:204.0/255.0 blue:204.0/255.0 alpha:1].CGColor;
    _viSelectItem.layer.cornerRadius = 8.0f;
  //  [_txtPhoneNumber setKeyboardType:UIKeyboardTypeNumberPad];

}
- (IBAction)btnAttachment:(id)sender {
    
    actionsheet = [[UIActionSheet alloc]initWithTitle:@"UPLOAD IMAGE" delegate:self cancelButtonTitle:@"cancel" destructiveButtonTitle:nil otherButtonTitles:@"Gallery",@"Camera", nil];
    [actionsheet showInView:self.view];
    }
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(buttonIndex == 0){
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary]){
            imagePicker = [[UIImagePickerController alloc]init];
            imagePicker.delegate = self;
            imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [self presentViewController:imagePicker animated:YES completion:nil];
        
    }
    }
        if([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
            imagePicker = [[UIImagePickerController alloc]init];
            imagePicker.delegate = self;
            imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
            [self presentViewController:imagePicker animated:YES completion:nil];
            
        }else{
            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"error accessing" message:@"Device does not support" delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil, nil];
            [alert show];
        }
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info{
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    UIImage *scaledImage = [self imageWithImage:image andWidth:image.size.width/2 andHeight:image.size.height/2];
    NSData *finalData = UIImagePNGRepresentation(scaledImage);
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *documentsPath = [paths objectAtIndex:0];
    //  NSString *folderpath = @"helpdesk/";
    NSString *phonepath = _txtPhoneNumber.text;
    phoneimagepath = [NSString stringWithFormat:@"%@/%@",documentsPath,phonepath];
    BOOL isDir;
    NSFileManager *fileManager= [NSFileManager defaultManager];
    if(![fileManager fileExistsAtPath:phoneimagepath isDirectory:&isDir])
        if(![fileManager createDirectoryAtPath:phoneimagepath withIntermediateDirectories:YES attributes:nil error:NULL])
            NSLog(@"Error: folder creation failed %lu", (unsigned long)NSDocumentDirectory);
    [[NSFileManager defaultManager] createFileAtPath:[NSString stringWithFormat:@"%@/%s", phoneimagepath, "ganesh.jpg"] contents:nil attributes:nil];
    [finalData writeToFile:[NSString stringWithFormat:@"%@/%s",phoneimagepath, "ganesh.jpg"] atomically:YES];
    filePath1 = [NSString stringWithFormat:@"%@/%s", phoneimagepath,"ganesh.jpg"];
    [captuerimage setImage:image];
    [imagePicker dismissViewControllerAnimated:YES completion:nil];
}
- (UIImage*)imageWithImage:(UIImage*)image andWidth:(CGFloat)width andHeight:(CGFloat)height
{
    UIGraphicsBeginImageContext( CGSizeMake(width, height));
    [image drawInRect:CGRectMake(0,0,width,height)];
    UIImage* newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext() ;
    return newImage;
}
-(BOOL) NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = NO;
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

//scroll view
- (void)viewDidLayoutSubviews
{
    [_scroll setContentSize:CGSizeMake(320, 1000)];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
// The number of rows of data
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return _arrayNo.count;
}
// The data to return for the row and component (column) that's being passed in
- (NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return _arrayNo[row];
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
    _picker.hidden = YES;
    _txtSelectItem.text = _arrayNo[row];
}
// touch

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [_txtSelectItem resignFirstResponder];
    [_txtLocation resignFirstResponder];
    [_txtPhoneNumber resignFirstResponder];
  
    
    return YES;
}
- (BOOL)textView:(UITextView *)_txtMessage shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if( [text rangeOfCharacterFromSet:[NSCharacterSet newlineCharacterSet]].location == NSNotFound ) {
        return YES;
    }
    
    [_txtMessage resignFirstResponder];
    return NO;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}
- (IBAction)verifying:(id)sender {
    NSString *countryCode = [NSString stringWithFormat:@"%s","+91"];
    NSString *phone = [NSString stringWithFormat:@"%@%@",countryCode,_txtPhoneNumber.text];
   // NSString *phone = _txtPhoneNumber.text;
    [[FIRPhoneAuthProvider provider] verifyPhoneNumber:[NSString stringWithFormat:@"%@",phone]
                                            UIDelegate:nil
                                            completion:^(NSString * _Nullable verificationID, NSError * _Nullable error) {
                                                if (error) {
                                                    UIAlertController * erroralertController = [UIAlertController alertControllerWithTitle: @"Error"
                                                                                                                              message: @"enter valid number"
                                                                                                                       preferredStyle:UIAlertControllerStyleAlert];
                                                    [self presentViewController:erroralertController animated:YES completion:nil];
                                                    NSLog(@"Push Error");
                                                    return;
                                                }
                                                NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                                                [defaults setObject:verificationID forKey:@"authVerificationID"];
//                                                VerifyViewController *rc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]
//                                                                                    instantiateViewControllerWithIdentifier:@"VerifyViewController"];
//                                                [self.navigationController pushViewController:rc animated:YES];
//                                                
                                                UIAlertController * alertController = [UIAlertController alertControllerWithTitle: @"Verification"
                                                                                                                          message: @"Input 6 digit number"
                                                                                                                   preferredStyle:UIAlertControllerStyleAlert];
                                                [alertController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
                                                    textField.placeholder = @"6 digit number";
                                                    textField.textColor = [UIColor blueColor];
                                                    textField.clearButtonMode = UITextFieldViewModeWhileEditing;
                                                    textField.borderStyle = UITextBorderStyleRoundedRect;
                                                }];
                                                
                                                [alertController addAction:[UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                    NSArray * textfields = alertController.textFields;
                                                    UITextField * namefield = textfields[0];
                                                    
                                                    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                                                    NSString *verificationID = [defaults stringForKey:@"authVerificationID"];
                                                    
                                                    FIRAuthCredential *credential = [[FIRPhoneAuthProvider provider]
                                                                                     credentialWithVerificationID:verificationID
                                                                                     verificationCode:namefield.text];
                                                    [[FIRAuth auth] signInWithCredential:credential
                                                                              completion:^(FIRUser *user, NSError *error) {
                                                                                  if (error) {
                                                                                      NSLog(error);
                                                                                      
                                                                                      
                                                                                  }
                                                                                  _imgVerification.image = [UIImage imageNamed: @"verified.png"];
                                                                                  NSLog(@"sucess");
                                                                                  self.btnVerify.enabled = NO;
                                                                                  _btnVerify.alpha = 0;
                                                                              }];
                                                   
                                                    NSLog(@"%@",namefield.text);
                                                    
                                                }]];
                                                [self presentViewController:alertController animated:YES completion:nil];
                                            }];
    
}


@end
