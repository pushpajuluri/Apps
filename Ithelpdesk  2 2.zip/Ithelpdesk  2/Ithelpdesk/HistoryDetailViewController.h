//
//  HistoryDetailViewController.h
//  Ithelpdesk
//
//  Created by omniwyse on 14/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoryDetailViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblNumber;
@property (weak, nonatomic) IBOutlet UILabel *lblMail;
@property (weak, nonatomic) IBOutlet UILabel *lblLocation;
@property (weak, nonatomic) IBOutlet UIImageView *imgCaptured;
@property (weak,nonatomic) NSArray *detail;

@end
