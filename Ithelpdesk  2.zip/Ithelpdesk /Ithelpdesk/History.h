//
//  History.h
//  Ithelpdesk
//
//  Created by omniwyse on 13/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface History : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *lblHistory;
@property (weak, nonatomic) IBOutlet UIImageView *imgStatus;

@end
