//
//  LoginViewController.h
//  Ithelpdesk
//
//  Created by omniwyse on 07/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
{
     NSMutableDictionary *loginDict;
}
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtPassword;
@property (weak, nonatomic) IBOutlet UIView *viPassword;
@property (weak, nonatomic) IBOutlet UIView *viName;

@end
