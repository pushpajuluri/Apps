//
//  HistoryViewController.m
//  Ithelpdesk
//
//  Created by omniwyse on 13/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import "HistoryViewController.h"
#import "History.h"
#import "HistoryDetailViewController.h"

@interface HistoryViewController ()

@end

@implementation HistoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSManagedObjectContext *managedObjectContext = [self managedObjectContext];
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:@"IthelpdeskEntity"];
    self.devices = [[managedObjectContext executeFetchRequest:fetchRequest error:nil] mutableCopy];
    NSLog(@"Name:%@\n",[_devices valueForKey:@"name"]);
    [self.tableview reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (NSManagedObjectContext *)managedObjectContext
{
    NSManagedObjectContext *context = nil;
    id delegate = [[UIApplication sharedApplication] delegate];
    if ([delegate performSelector:@selector(managedObjectContext)]) {
        context = [delegate managedObjectContext];
    }
    return context;
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return self.devices.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    History *cell = [self.tableview dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    
    if (cell == nil) {
        cell = [[History alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    NSManagedObject *device = [self.devices objectAtIndex:indexPath.row];
    [cell.lblHistory setText:[NSString stringWithFormat:@"%@", [device valueForKey:@"mobile"]]];
    NSString *value =  [device valueForKey:@"statussync"];
    if ([value  isEqual: @"yes"]){
        cell.imgStatus.image = [UIImage imageNamed: @"verified.png"];
       
    }else{
         cell.imgStatus.image = [UIImage imageNamed: @"ex.png"];
    }
    
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
     NSArray *device = [self.devices objectAtIndex:indexPath.row];
//    HistoryDetailViewController *history = [[HistoryDetailViewController alloc] init];
//    history.detail = device;
    HistoryDetailViewController *rc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]
                          instantiateViewControllerWithIdentifier:@"HistoryDetailViewController"];
    rc.detail = device;
    [self.navigationController pushViewController:rc animated:YES];
}

@end
