//
//  LoginViewController.m
//  Ithelpdesk
//
//  Created by omniwyse on 07/11/17.
//  Copyright © 2017 omniwyse. All rights reserved.
//

#import "LoginViewController.h"
#import "ViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
     loginDict = [[NSMutableDictionary alloc] init];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [_txtName resignFirstResponder];
    [_txtPassword resignFirstResponder];
  
    
    return YES;
}
- (IBAction)btnLogin:(id)sender {
    NSString *userName = _txtName.text;
    NSString *password = _txtPassword.text;
    
    [loginDict setObject:userName forKey:@"userName"];
    [loginDict setObject:password forKey:@"password"];
    
    NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:userName,@"userName",password,@"password", nil, nil];
    
//    if([[loginDict valueForKey:@"userName"] isEqualToString:@"Abhishek"])
//        NSLog(@"User is valid");
//    else
//        NSLog(@"User is not valid");
    
    if([[loginDict valueForKey:@"userName"] isEqualToString:@""] && [[loginDict valueForKey:@"password"] isEqualToString:@""]){
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"OK"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        
                                    }];
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"ERROR"
                                     message:@"Enter valid information"
                                     preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:yesButton];
        [self presentViewController:alert animated:YES completion:nil];
        
    }
    
    else  if ( [[loginDict valueForKey:@"userName"] isEqualToString:@"sam"] && [[loginDict valueForKey:@"password"] isEqualToString:@"sam"]
              ) {
        ViewController *rc = [[UIStoryboard storyboardWithName:@"Main" bundle:nil]
                                            instantiateViewControllerWithIdentifier:@"ViewController"];
        [self.navigationController pushViewController:rc animated:YES];
    }
    else{
        
        UIAlertAction* yesButton = [UIAlertAction
                                    actionWithTitle:@"OK"
                                    style:UIAlertActionStyleDefault
                                    handler:^(UIAlertAction * action) {
                                        
                                    }];
        UIAlertController * alert = [UIAlertController
                                     alertControllerWithTitle:@"ERROR"
                                     message:@"password is incorrect"
                                     preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:yesButton];
        [self presentViewController:alert animated:YES completion:nil];
        
    }
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
